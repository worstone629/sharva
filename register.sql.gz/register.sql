-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2023 at 09:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_post`
--

CREATE TABLE `admin_post` (
  `sno` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `category` varchar(60) NOT NULL,
  `photo1` varchar(600) NOT NULL,
  `photo2` varchar(600) NOT NULL,
  `photo3` varchar(600) NOT NULL,
  `bank_branch` varchar(60) NOT NULL,
  `account_no` int(60) NOT NULL,
  `IFSC_code` varchar(60) NOT NULL,
  `money_raise` int(80) NOT NULL,
  `paytm_no` int(20) NOT NULL,
  `gpay_no` int(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_post`
--

INSERT INTO `admin_post` (`sno`, `name`, `email`, `title`, `description`, `category`, `photo1`, `photo2`, `photo3`, `bank_branch`, `account_no`, `IFSC_code`, `money_raise`, `paytm_no`, `gpay_no`, `date`) VALUES
(1, 'shambhu nath maji', 'majishambunath@gmailo.com', 'sasdada', 'asdadsadasd', 'destruction', '2870622_6431.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 453434534, 453434533, 454354543, '2023-04-16 20:42:24'),
(2, 'aritra pal', 'majishambunath@gmailo.com', 'titile of education', 'description on education', 'education', '22635601_6665831.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 1000000, 453434533, 454354543, '2023-04-16 20:42:24'),
(3, 'arghadip', 'arghadip@gmailo.com', 'titile of destruction', 'description on dstruction', 'education', '22635601_6665831.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 10000, 453434533, 454354543, '2023-04-16 20:42:24'),
(4, 'mishra', 'misrha@gmail.com', 'title of medical', 'asdadsadasd', 'destruction', '2870622_6431.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 100000000, 453434533, 454354543, '2023-04-16 20:42:24'),
(5, 'ram', 'ram@gmailo.com', 'titile of animal', 'description on animal', 'education', '22635601_6665831.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 100000, 453434533, 454354543, '2023-04-16 20:42:24'),
(6, 'joy', 'arghadip@gmailo.com', 'titile of creative', 'description on creative', 'education', '22635601_6665831.jpg', '2870622_6431.jpg', '2870622_6431.jpg', 'asdadas', 432453, 'hfg432453', 1000000, 453434533, 454354543, '2023-04-16 20:42:24'),
(7, 'deadly zeke', 'zeke@gmail.com', 'title for destruction in nepal', 'description for destruction in nepal', 'destruction', '31829435_x243_1614_220822.jpg', '31829435_x243_1614_220822.jpg', '31829435_x243_1614_220822.jpg', 'fci', 10151313, 'asd1313', 10000000, 165651665, 16313531, '2023-04-16 21:25:32'),
(8, 'helloboy', 'helloboy@gmail.com', 'this is the title for medical purpose', 'this is the description for medical purpose', 'medical', '31829435_x243_1614_220822.jpg', '3330829_694.jpg', '2799369_17059.jpg', 'fci', 2147483647, 'ifs556562', 1000000, 56165161, 46546565, '2023-04-16 21:36:51');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_title`) VALUES
(1, 'destruction'),
(2, 'education'),
(3, 'animal'),
(4, 'medical'),
(5, 'creative'),
(6, 'envioment'),
(7, 'children'),
(8, 'development'),
(9, 'food'),
(10, 'sports'),
(11, 'fighter');

-- --------------------------------------------------------

--
-- Table structure for table `fundriser`
--

CREATE TABLE `fundriser` (
  `sno` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `photo1` varchar(200) NOT NULL,
  `photo2` varchar(200) NOT NULL,
  `photo3` varchar(200) NOT NULL,
  `Bank_branch` varchar(10) NOT NULL,
  `account_no` int(60) NOT NULL,
  `IFSC_code` varchar(60) NOT NULL,
  `paytm_no` int(60) NOT NULL,
  `gpay_no` int(60) NOT NULL,
  `category` varchar(90) NOT NULL,
  `money_raise` int(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fundriser`
--

INSERT INTO `fundriser` (`sno`, `name`, `email`, `title`, `description`, `photo1`, `photo2`, `photo3`, `Bank_branch`, `account_no`, `IFSC_code`, `paytm_no`, `gpay_no`, `category`, `money_raise`, `date`) VALUES
(15, 'suman', 'majishambhunath@gmail.com', 'glbbjnjlk', 'dadadasdsa', '33112190_j-v44-mint-51-animals-e.jpg', '2870622_6431.jpg', '22635601_6665831.jpg', 'asd', 56465461, 'asd5631656', 313211532, 1616516516, '5', 2147483647, '2023-04-16 19:55:11'),
(16, 'suman', 'majishambhunath@gmail.com', 'glbbjnjlk', 'dadadasdsa', '33112190_j-v44-mint-51-animals-e.jpg', '2870622_6431.jpg', '22635601_6665831.jpg', 'asd', 56465461, 'asd5631656', 313211532, 1616516516, '5', 2147483647, '2023-04-16 19:56:53'),
(17, 'deadly zeke', 'zeke@gmail.com', 'title for destruction in nepal', 'description for destruction in nepal', '31829435_x243_1614_220822.jpg', '3330829_694.jpg', '2799369_17059.jpg', 'fci', 2147483647, '5465511', 2147483647, 2147483647, '1', 1000000, '2023-04-16 21:20:06'),
(18, 'helloboy', 'helloboy@gmail.com', 'this is the title for medical purpose', 'this is the description for medical purpose', '31829435_x243_1614_220822.jpg', '3330829_694.jpg', '2799369_17059.jpg', 'fci', 2147483647, 'ifs556562', 46546565, 56165161, '4', 1000000, '2023-04-16 21:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `sno` int(110) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `sno` int(110) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` text NOT NULL,
  `password` varchar(23) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `cpassword` varchar(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`sno`, `email`, `username`, `password`, `phone`, `cpassword`, `date`) VALUES
(1, 'suman@gmail.com', 'Worst123', '5647', '8293092857', '5647', '2023-04-13 00:58:24'),
(3, 'zeke@gmail.com', 'zeke', '123456ty', '1234567890', '123456ty', '2023-04-13 01:00:23'),
(6, 'happy@gmail.com', 'happyboy', 'happyboy', '8293095468', 'happyboy', '2023-04-15 01:03:18'),
(7, 'helloboy@gmail.com', 'helloboy', 'helloboy', '2536478940', 'helloboy', '2023-04-16 21:31:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_post`
--
ALTER TABLE `admin_post`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `fundriser`
--
ALTER TABLE `fundriser`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `username` (`username`) USING HASH;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_post`
--
ALTER TABLE `admin_post`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `fundriser`
--
ALTER TABLE `fundriser`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `sno` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `sno` int(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
